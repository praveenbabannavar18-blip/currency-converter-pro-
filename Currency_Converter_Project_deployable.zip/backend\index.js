const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const os = require('os');

const app = express();
const PORT = process.env.PORT || 5005;
const HOST = process.env.HOST || '0.0.0.0';

app.use(cors());
app.use(express.json());

// Initialize SQLite Database
const dbPath = path.join(__dirname, 'currency_converter.db');
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('Error opening database:', err);
  } else {
    console.log('Connected to SQLite database');
    initializeDatabase();
  }
});

// Initialize database tables
function initializeDatabase() {
  db.serialize(() => {
    // Users table
    db.run(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        name TEXT NOT NULL,
        role TEXT DEFAULT 'user',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Conversion history table
    db.run(`
      CREATE TABLE IF NOT EXISTS conversion_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        from_currency TEXT NOT NULL,
        to_currency TEXT NOT NULL,
        amount REAL NOT NULL,
        result REAL NOT NULL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
      )
    `);

    db.run(`
      CREATE TABLE IF NOT EXISTS expense_split_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        base_currency TEXT NOT NULL,
        total_amount REAL NOT NULL,
        people_count INTEGER NOT NULL,
        target_currencies TEXT NOT NULL,
        per_person_amount REAL NOT NULL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
      )
    `);

    // Insert default users if they don't exist
    db.get("SELECT * FROM users WHERE email = ?", ['admin1234@gmail.com'], (err, row) => {
      if (!row) {
        db.run("INSERT INTO users (email, password, name, role) VALUES (?, ?, ?, ?)", 
          ['admin1234@gmail.com', 'Admin@123', 'Admin', 'admin']);
      }
    });

    db.get("SELECT * FROM users WHERE email = ?", ['user@currency.com'], (err, row) => {
      if (!row) {
        db.run("INSERT INTO users (email, password, name, role) VALUES (?, ?, ?, ?)", 
          ['user@currency.com', 'user123', 'User', 'user']);
      }
    });
  });
}

let currencies = [
  { code: 'USD', name: 'United States Dollar', flag: '🇺🇸', active: true },
  { code: 'EUR', name: 'Euro', flag: '🇪🇺', active: true },
  { code: 'GBP', name: 'British Pound Sterling', flag: '🇬🇧', active: true },
  { code: 'JPY', name: 'Japanese Yen', flag: '🇯🇵', active: true },
  { code: 'AUD', name: 'Australian Dollar', flag: '🇦🇺', active: true },
  { code: 'CAD', name: 'Canadian Dollar', flag: '🇨🇦', active: true },
  { code: 'CHF', name: 'Swiss Franc', flag: '🇨🇭', active: true },
  { code: 'CNY', name: 'Chinese Yuan', flag: '🇨🇳', active: true },
  { code: 'INR', name: 'Indian Rupee', flag: '🇮🇳', active: true },
  { code: 'BRL', name: 'Brazilian Real', flag: '🇧🇷', active: true },
  { code: 'ZAR', name: 'South African Rand', flag: '🇿🇦', active: true },
  { code: 'MXN', name: 'Mexican Peso', flag: '🇲🇽', active: true },
  { code: 'SGD', name: 'Singapore Dollar', flag: '🇸🇬', active: true },
  { code: 'HKD', name: 'Hong Kong Dollar', flag: '🇭🇰', active: true },
  { code: 'SEK', name: 'Swedish Krona', flag: '🇸🇪', active: true },
  { code: 'NOK', name: 'Norwegian Krone', flag: '🇳🇴', active: true },
  { code: 'DKK', name: 'Danish Krone', flag: '🇩🇰', active: true },
  { code: 'NZD', name: 'New Zealand Dollar', flag: '🇳🇿', active: true },
  { code: 'RUB', name: 'Russian Ruble', flag: '🇷🇺', active: true },
  { code: 'TRY', name: 'Turkish Lira', flag: '🇹🇷', active: true },
  { code: 'PLN', name: 'Polish Zloty', flag: '🇵🇱', active: true },
  { code: 'THB', name: 'Thai Baht', flag: '🇹🇭', active: true },
  { code: 'IDR', name: 'Indonesian Rupiah', flag: '🇮🇩', active: true },
  { code: 'MYR', name: 'Malaysian Ringgit', flag: '🇲🇾', active: true },
  { code: 'PHP', name: 'Philippine Peso', flag: '🇵🇭', active: true },
  { code: 'AED', name: 'UAE Dirham', flag: '🇦🇪', active: true },
  { code: 'SAR', name: 'Saudi Riyal', flag: '🇸🇦', active: true },
  { code: 'EGP', name: 'Egyptian Pound', flag: '🇪🇬', active: true },
  { code: 'VND', name: 'Vietnamese Dong', flag: '🇻🇳', active: true },
];

let nextCurrencyId = 100;

currencies = [
  { code: 'AED', name: 'UAE Dirham', flag: 'AE', active: true },
  { code: 'ARS', name: 'Argentine Peso', flag: 'AR', active: true },
  { code: 'AUD', name: 'Australian Dollar', flag: 'AU', active: true },
  { code: 'BDT', name: 'Bangladeshi Taka', flag: 'BD', active: true },
  { code: 'BGN', name: 'Bulgarian Lev', flag: 'BG', active: true },
  { code: 'BHD', name: 'Bahraini Dinar', flag: 'BH', active: true },
  { code: 'BND', name: 'Brunei Dollar', flag: 'BN', active: true },
  { code: 'BOB', name: 'Bolivian Boliviano', flag: 'BO', active: true },
  { code: 'BRL', name: 'Brazilian Real', flag: 'BR', active: true },
  { code: 'BWP', name: 'Botswana Pula', flag: 'BW', active: true },
  { code: 'BYN', name: 'Belarusian Ruble', flag: 'BY', active: true },
  { code: 'CAD', name: 'Canadian Dollar', flag: 'CA', active: true },
  { code: 'CHF', name: 'Swiss Franc', flag: 'CH', active: true },
  { code: 'CLP', name: 'Chilean Peso', flag: 'CL', active: true },
  { code: 'CNY', name: 'Chinese Yuan', flag: 'CN', active: true },
  { code: 'COP', name: 'Colombian Peso', flag: 'CO', active: true },
  { code: 'CRC', name: 'Costa Rican Colon', flag: 'CR', active: true },
  { code: 'CZK', name: 'Czech Koruna', flag: 'CZ', active: true },
  { code: 'DKK', name: 'Danish Krone', flag: 'DK', active: true },
  { code: 'DOP', name: 'Dominican Peso', flag: 'DO', active: true },
  { code: 'DZD', name: 'Algerian Dinar', flag: 'DZ', active: true },
  { code: 'EGP', name: 'Egyptian Pound', flag: 'EG', active: true },
  { code: 'ETB', name: 'Ethiopian Birr', flag: 'ET', active: true },
  { code: 'EUR', name: 'Euro', flag: 'EU', active: true },
  { code: 'FJD', name: 'Fijian Dollar', flag: 'FJ', active: true },
  { code: 'GBP', name: 'British Pound Sterling', flag: 'GB', active: true },
  { code: 'GEL', name: 'Georgian Lari', flag: 'GE', active: true },
  { code: 'GHS', name: 'Ghanaian Cedi', flag: 'GH', active: true },
  { code: 'GTQ', name: 'Guatemalan Quetzal', flag: 'GT', active: true },
  { code: 'HKD', name: 'Hong Kong Dollar', flag: 'HK', active: true },
  { code: 'HNL', name: 'Honduran Lempira', flag: 'HN', active: true },
  { code: 'HUF', name: 'Hungarian Forint', flag: 'HU', active: true },
  { code: 'IDR', name: 'Indonesian Rupiah', flag: 'ID', active: true },
  { code: 'ILS', name: 'Israeli New Shekel', flag: 'IL', active: true },
  { code: 'INR', name: 'Indian Rupee', flag: 'IN', active: true },
  { code: 'ISK', name: 'Icelandic Krona', flag: 'IS', active: true },
  { code: 'JMD', name: 'Jamaican Dollar', flag: 'JM', active: true },
  { code: 'JOD', name: 'Jordanian Dinar', flag: 'JO', active: true },
  { code: 'JPY', name: 'Japanese Yen', flag: 'JP', active: true },
  { code: 'KES', name: 'Kenyan Shilling', flag: 'KE', active: true },
  { code: 'KRW', name: 'South Korean Won', flag: 'KR', active: true },
  { code: 'KWD', name: 'Kuwaiti Dinar', flag: 'KW', active: true },
  { code: 'KZT', name: 'Kazakhstani Tenge', flag: 'KZ', active: true },
  { code: 'LBP', name: 'Lebanese Pound', flag: 'LB', active: true },
  { code: 'LKR', name: 'Sri Lankan Rupee', flag: 'LK', active: true },
  { code: 'MAD', name: 'Moroccan Dirham', flag: 'MA', active: true },
  { code: 'MDL', name: 'Moldovan Leu', flag: 'MD', active: true },
  { code: 'MUR', name: 'Mauritian Rupee', flag: 'MU', active: true },
  { code: 'MXN', name: 'Mexican Peso', flag: 'MX', active: true },
  { code: 'MYR', name: 'Malaysian Ringgit', flag: 'MY', active: true },
  { code: 'NGN', name: 'Nigerian Naira', flag: 'NG', active: true },
  { code: 'NIO', name: 'Nicaraguan Cordoba', flag: 'NI', active: true },
  { code: 'NOK', name: 'Norwegian Krone', flag: 'NO', active: true },
  { code: 'NPR', name: 'Nepalese Rupee', flag: 'NP', active: true },
  { code: 'NZD', name: 'New Zealand Dollar', flag: 'NZ', active: true },
  { code: 'OMR', name: 'Omani Rial', flag: 'OM', active: true },
  { code: 'PEN', name: 'Peruvian Sol', flag: 'PE', active: true },
  { code: 'PHP', name: 'Philippine Peso', flag: 'PH', active: true },
  { code: 'PKR', name: 'Pakistani Rupee', flag: 'PK', active: true },
  { code: 'PLN', name: 'Polish Zloty', flag: 'PL', active: true },
  { code: 'QAR', name: 'Qatari Riyal', flag: 'QA', active: true },
  { code: 'RON', name: 'Romanian Leu', flag: 'RO', active: true },
  { code: 'RSD', name: 'Serbian Dinar', flag: 'RS', active: true },
  { code: 'RUB', name: 'Russian Ruble', flag: 'RU', active: true },
  { code: 'SAR', name: 'Saudi Riyal', flag: 'SA', active: true },
  { code: 'SEK', name: 'Swedish Krona', flag: 'SE', active: true },
  { code: 'SGD', name: 'Singapore Dollar', flag: 'SG', active: true },
  { code: 'THB', name: 'Thai Baht', flag: 'TH', active: true },
  { code: 'TND', name: 'Tunisian Dinar', flag: 'TN', active: true },
  { code: 'TRY', name: 'Turkish Lira', flag: 'TR', active: true },
  { code: 'TWD', name: 'New Taiwan Dollar', flag: 'TW', active: true },
  { code: 'TZS', name: 'Tanzanian Shilling', flag: 'TZ', active: true },
  { code: 'UAH', name: 'Ukrainian Hryvnia', flag: 'UA', active: true },
  { code: 'UGX', name: 'Ugandan Shilling', flag: 'UG', active: true },
  { code: 'USD', name: 'United States Dollar', flag: 'US', active: true },
  { code: 'UYU', name: 'Uruguayan Peso', flag: 'UY', active: true },
  { code: 'UZS', name: 'Uzbekistani Som', flag: 'UZ', active: true },
  { code: 'VND', name: 'Vietnamese Dong', flag: 'VN', active: true },
  { code: 'XAF', name: 'Central African CFA Franc', flag: 'CF', active: true },
  { code: 'XCD', name: 'East Caribbean Dollar', flag: 'AG', active: true },
  { code: 'XOF', name: 'West African CFA Franc', flag: 'SN', active: true },
  { code: 'YER', name: 'Yemeni Rial', flag: 'YE', active: true },
  { code: 'ZAR', name: 'South African Rand', flag: 'ZA', active: true },
  { code: 'ZMW', name: 'Zambian Kwacha', flag: 'ZM', active: true },
];

// Track logged-in users (in-memory session tracking)
let loggedInUsers = [];

const offlineBaseRates = {
  AED: 3.6725,
  ARS: 880.0,
  AUD: 1.52,
  BDT: 117.0,
  BGN: 1.81,
  BHD: 0.376,
  BND: 1.35,
  BOB: 6.91,
  BRL: 5.14,
  BWP: 13.7,
  BYN: 3.27,
  CAD: 1.37,
  CHF: 0.91,
  CLP: 945.0,
  CNY: 7.24,
  COP: 3895.0,
  CRC: 510.0,
  CZK: 22.8,
  DKK: 6.9,
  DOP: 58.9,
  DZD: 134.5,
  EGP: 48.2,
  ETB: 57.3,
  EUR: 0.92,
  FJD: 2.24,
  GBP: 0.79,
  GEL: 2.71,
  GHS: 14.8,
  GTQ: 7.74,
  HKD: 7.82,
  HNL: 24.7,
  HUF: 361.0,
  IDR: 16120.0,
  ILS: 3.69,
  INR: 83.3,
  ISK: 138.4,
  JMD: 156.7,
  JOD: 0.709,
  JPY: 155.0,
  KES: 129.0,
  KRW: 1362.0,
  KWD: 0.307,
  KZT: 447.0,
  LBP: 89500.0,
  LKR: 301.0,
  MAD: 9.95,
  MDL: 17.8,
  MUR: 46.5,
  MXN: 16.9,
  MYR: 4.71,
  NGN: 1460.0,
  NIO: 36.8,
  NOK: 10.8,
  NPR: 133.3,
  NZD: 1.64,
  OMR: 0.384,
  PEN: 3.73,
  PHP: 57.1,
  PKR: 278.0,
  PLN: 3.96,
  QAR: 3.64,
  RON: 4.58,
  RSD: 107.8,
  RUB: 91.0,
  SAR: 3.75,
  SEK: 10.7,
  SGD: 1.35,
  THB: 36.7,
  TND: 3.12,
  TRY: 32.2,
  TWD: 32.4,
  TZS: 2580.0,
  UAH: 39.4,
  UGX: 3810.0,
  USD: 1,
  UYU: 39.0,
  UZS: 12750.0,
  VND: 25450.0,
  XAF: 603.0,
  XCD: 2.7,
  XOF: 603.0,
  YER: 250.0,
  ZAR: 18.4,
  ZMW: 26.4,
};

function buildRatesFromBase(base) {
  const normalizedBase = String(base || '').toUpperCase();
  const baseValue = offlineBaseRates[normalizedBase];

  if (!baseValue) {
    return null;
  }

  return Object.fromEntries(
    Object.entries(offlineBaseRates).map(([code, usdRate]) => [
      code,
      usdRate / baseValue,
    ])
  );
}

function buildOfflineHistory(base, target, days = 30) {
  const normalizedBase = String(base || '').toUpperCase();
  const normalizedTarget = String(target || '').toUpperCase();
  const baseRates = buildRatesFromBase(normalizedBase);

  if (!baseRates || !baseRates[normalizedTarget]) {
    return null;
  }

  const currentRate = baseRates[normalizedTarget];
  const series = [];

  for (let offset = days - 1; offset >= 0; offset -= 1) {
    const date = new Date();
    date.setDate(date.getDate() - offset);

    const wave = Math.sin((days - offset) / 4) * 0.012;
    const drift = ((days - offset) / days - 0.5) * 0.01;
    const adjustedRate = Number((currentRate * (1 + wave + drift)).toFixed(6));

    series.push({
      date: date.toISOString().split('T')[0],
      rate: adjustedRate,
    });
  }

  return series;
}

// User login - track login status
app.post('/api/login', (req, res) => {
  const { email, password } = req.body;
  db.get("SELECT * FROM users WHERE email = ? AND password = ?", [email, password], (err, user) => {
    if (err) {
      return res.status(500).json({ success: false, error: 'Database error' });
    }
    if (user) {
      // Check if already logged in
      if (loggedInUsers.find(u => u.id === user.id)) {
        return res.json({ success: true, user: { id: user.id, email: user.email, name: user.name, role: user.role }, alreadyLoggedIn: true });
      }
      // Add to logged-in users
      const loginTime = new Date().toISOString();
      loggedInUsers.push({ 
        id: user.id, 
        email: user.email, 
        name: user.name, 
        role: user.role,
        loginTime 
      });
      res.json({ success: true, user: { id: user.id, email: user.email, name: user.name, role: user.role } });
    } else {
      res.status(401).json({ success: false, error: 'Invalid credentials' });
    }
  });
});

app.post('/api/register', (req, res) => {
  const { name, email, password } = req.body;

  if (!name || !email || !password) {
    return res.status(400).json({ error: 'All fields are required' });
  }

  if (password.length < 6) {
    return res.status(400).json({ error: 'Password must be at least 6 characters' });
  }

  db.get("SELECT id FROM users WHERE email = ?", [email], (err, row) => {
    if (err) {
      return res.status(500).json({ error: 'Database error' });
    }

    if (row) {
      return res.status(400).json({ error: 'Email already exists' });
    }

    db.run(
      "INSERT INTO users (email, password, name, role) VALUES (?, ?, ?, ?)",
      [email, password, name, 'user'],
      function(insertErr) {
        if (insertErr) {
          return res.status(500).json({ error: 'Failed to create account' });
        }

        res.status(201).json({
          success: true,
          user: {
            id: this.lastID,
            email,
            name,
            role: 'user',
          },
        });
      }
    );
  });
});

// User logout - remove from logged-in users
app.post('/api/logout', (req, res) => {
  const { userId } = req.body;
  const userIndex = loggedInUsers.findIndex(u => u.id === userId);
  if (userIndex !== -1) {
    loggedInUsers.splice(userIndex, 1);
  }
  res.json({ success: true });
});

// Get all logged-in users
app.get('/api/admin/logged-in-users', (req, res) => {
  res.json(loggedInUsers);
});

// Force logout a user
app.post('/api/admin/force-logout', (req, res) => {
  const { userId } = req.body;
  const userIndex = loggedInUsers.findIndex(u => u.id === userId);
  if (userIndex !== -1) {
    loggedInUsers.splice(userIndex, 1);
    res.json({ success: true, message: 'User forced to logout' });
  } else {
    res.status(404).json({ error: 'User not found in logged-in list' });
  }
});

// Admin login
app.post('/api/admin/login', (req, res) => {
  const { email, password } = req.body;
  db.get("SELECT * FROM users WHERE email = ? AND password = ? AND role = ?", [email, password, 'admin'], (err, user) => {
    if (err) {
      return res.status(500).json({ success: false, error: 'Database error' });
    }
    if (user) {
      res.json({ success: true, user: { id: user.id, email: user.email, name: user.name, role: user.role } });
    } else {
      res.status(401).json({ success: false, error: 'Invalid admin credentials' });
    }
  });
});

// Get all users
app.get('/api/admin/users', (req, res) => {
  db.all("SELECT id, email, name, role FROM users", (err, rows) => {
    if (err) {
      return res.status(500).json({ error: 'Database error' });
    }
    res.json(rows.map(u => ({ ...u, password: '***' })));
  });
});

// Add new user
app.post('/api/admin/users', (req, res) => {
  const { email, name, password } = req.body;
  db.get("SELECT id FROM users WHERE email = ?", [email], (err, row) => {
    if (err) {
      return res.status(500).json({ error: 'Database error' });
    }
    if (row) {
      return res.status(400).json({ error: 'Email already exists' });
    }
    db.run("INSERT INTO users (email, name, password, role) VALUES (?, ?, ?, ?)", 
      [email, name, password, 'user'], 
      function(err) {
        if (err) {
          return res.status(500).json({ error: 'Failed to create user' });
        }
        res.json({ id: this.lastID, email, name, password: '***', role: 'user' });
      }
    );
  });
});

// Update user
app.put('/api/admin/users/:id', (req, res) => {
  const { id } = req.params;
  const { email, name, password } = req.body;
  
  db.get("SELECT * FROM users WHERE id = ?", [id], (err, user) => {
    if (err || !user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    if (email && email !== user.email) {
      db.get("SELECT id FROM users WHERE email = ?", [email], (err, row) => {
        if (row) {
          return res.status(400).json({ error: 'Email already exists' });
        }
        updateUser();
      });
    } else {
      updateUser();
    }
    
    function updateUser() {
      const newEmail = email || user.email;
      const newName = name || user.name;
      const newPassword = password || user.password;
      
      db.run("UPDATE users SET email = ?, name = ?, password = ? WHERE id = ?", 
        [newEmail, newName, newPassword, id], 
        function(err) {
          if (err) {
            return res.status(500).json({ error: 'Failed to update user' });
          }
          res.json({ id: parseInt(id), email: newEmail, name: newName, password: '***', role: user.role });
        }
      );
    }
  });
});

// Delete user
app.delete('/api/admin/users/:id', (req, res) => {
  const { id } = req.params;
  db.get("SELECT role FROM users WHERE id = ?", [id], (err, user) => {
    if (err || !user) {
      return res.status(404).json({ error: 'User not found' });
    }
    if (user.role === 'admin') {
      return res.status(400).json({ error: 'Cannot delete admin' });
    }
    db.run("DELETE FROM users WHERE id = ?", [id], function(err) {
      if (err) {
        return res.status(500).json({ error: 'Failed to delete user' });
      }
      res.json({ success: true });
    });
  });
});

// Get all currencies
app.get('/api/admin/currencies', (req, res) => {
  res.json(currencies);
});

// Add new currency
app.post('/api/admin/currencies', (req, res) => {
  const { code, name, flag } = req.body;
  if (currencies.find(c => c.code === code)) {
    return res.status(400).json({ error: 'Currency code already exists' });
  }
  const newCurrency = { id: nextCurrencyId++, code: code.toUpperCase(), name, flag, active: true };
  currencies.push(newCurrency);
  res.json(newCurrency);
});

// Update currency
app.put('/api/admin/currencies/:code', (req, res) => {
  const { code } = req.params;
  const { name, flag, active } = req.body;
  const currencyIndex = currencies.findIndex(c => c.code === code.toUpperCase());
  if (currencyIndex === -1) return res.status(404).json({ error: 'Currency not found' });
  currencies[currencyIndex] = { 
    ...currencies[currencyIndex], 
    ...(name && { name }), 
    ...(flag && { flag }),
    ...(active !== undefined && { active })
  };
  res.json(currencies[currencyIndex]);
});

// Delete currency
app.delete('/api/admin/currencies/:code', (req, res) => {
  const { code } = req.params;
  const currencyIndex = currencies.findIndex(c => c.code === code.toUpperCase());
  if (currencyIndex === -1) return res.status(404).json({ error: 'Currency not found' });
  currencies.splice(currencyIndex, 1);
  res.json({ success: true });
});

// Get active currencies for converter
app.get('/api/currencies', (req, res) => {
  res.json(currencies.filter(c => c.active));
});

app.get('/health', (req, res) => res.send('OK'));

// Get latest exchange rates
app.get('/api/rates/:base', async (req, res) => {
  const { base } = req.params;
  const rates = buildRatesFromBase(base);

  if (!rates) {
    return res.status(404).json({ error: `Unsupported base currency: ${String(base).toUpperCase()}` });
  }

  res.json({
    base: String(base).toUpperCase(),
    date: new Date().toISOString().split('T')[0],
    offline: true,
    rates,
  });
});

// Get historical rates for last 30 days
app.get('/api/history/:base/:target', async (req, res) => {
  const { base, target } = req.params;
  const historyData = buildOfflineHistory(base, target);

  if (!historyData) {
    return res.status(404).json({
      error: `Unsupported currency pair: ${String(base).toUpperCase()} to ${String(target).toUpperCase()}`,
    });
  }

  res.json(historyData);
});

// Store conversion history
app.post('/api/conversion', (req, res) => {
  const { user_id, from_currency, to_currency, amount, result, timestamp } = req.body;
  
  if (!user_id || !from_currency || !to_currency || amount === undefined || result === undefined) {
    return res.status(400).json({ error: 'Missing required fields' });
  }
  
  // Use provided timestamp or default to current time
  const timestampValue = timestamp || new Date().toISOString();
  
  db.run("INSERT INTO conversion_history (user_id, from_currency, to_currency, amount, result, timestamp) VALUES (?, ?, ?, ?, ?, ?)", 
    [user_id, from_currency, to_currency, amount, result, timestampValue], 
    function(err) {
      if (err) {
        return res.status(500).json({ error: 'Failed to store conversion' });
      }
      res.json({ 
        success: true, 
        id: this.lastID,
        user_id,
        from_currency,
        to_currency,
        amount,
        result,
        timestamp: timestampValue
      });
    }
  );
});

app.post('/api/expense-split-history', (req, res) => {
  const {
    user_id,
    base_currency,
    total_amount,
    people_count,
    target_currencies,
    per_person_amount,
    timestamp,
  } = req.body;

  if (
    !user_id ||
    !base_currency ||
    total_amount === undefined ||
    !people_count ||
    !Array.isArray(target_currencies) ||
    target_currencies.length === 0 ||
    per_person_amount === undefined
  ) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const timestampValue = timestamp || new Date().toISOString();

  db.run(
    `INSERT INTO expense_split_history
      (user_id, base_currency, total_amount, people_count, target_currencies, per_person_amount, timestamp)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [
      user_id,
      String(base_currency).toUpperCase(),
      total_amount,
      people_count,
      JSON.stringify(target_currencies.map((code) => String(code).toUpperCase())),
      per_person_amount,
      timestampValue,
    ],
    function(err) {
      if (err) {
        return res.status(500).json({ error: 'Failed to store expense split history' });
      }

      res.json({
        success: true,
        id: this.lastID,
        user_id,
        base_currency: String(base_currency).toUpperCase(),
        total_amount,
        people_count,
        target_currencies,
        per_person_amount,
        timestamp: timestampValue,
      });
    }
  );
});

// Password-protected export of conversion history (for PDF download in the app)
app.post('/api/conversion-history/export', (req, res) => {
  const { userId, password } = req.body || {};
  const id = Number(userId);

  if (!userId || Number.isNaN(id) || password === undefined || String(password).length === 0) {
    return res.status(400).json({ error: 'userId and password are required' });
  }

  db.get('SELECT id FROM users WHERE id = ? AND password = ?', [id, password], (err, row) => {
    if (err) {
      return res.status(500).json({ error: 'Database error' });
    }
    if (!row) {
      return res.status(401).json({ error: 'Invalid password' });
    }

    db.all(
      'SELECT id, user_id, from_currency, to_currency, amount, result, timestamp FROM conversion_history WHERE user_id = ? ORDER BY timestamp DESC LIMIT 100',
      [id],
      (fetchErr, rows) => {
        if (fetchErr) {
          return res.status(500).json({ error: 'Database error' });
        }
        res.json({ success: true, history: rows || [] });
      }
    );
  });
});

// Get conversion history for a specific user
app.get('/api/conversion-history/:userId', (req, res) => {
  const { userId } = req.params;
  db.all("SELECT * FROM conversion_history WHERE user_id = ? ORDER BY timestamp DESC LIMIT 100", [userId], (err, rows) => {
    if (err) {
      return res.status(500).json({ error: 'Database error' });
    }
    res.json(rows || []);
  });
});

// Get all conversion history (for admin)
app.get('/api/admin/conversion-history', (req, res) => {
  const query = `
    SELECT 
      ch.id,
      ch.user_id,
      u.name as user_name,
      u.email as user_email,
      ch.from_currency,
      ch.to_currency,
      ch.amount,
      ch.result,
      ch.timestamp
    FROM conversion_history ch
    JOIN users u ON ch.user_id = u.id
    ORDER BY ch.timestamp DESC
    LIMIT 1000
  `;
  
  db.all(query, (err, rows) => {
    if (err) {
      console.error('Error fetching conversion history:', err);
      return res.status(500).json({ error: 'Database error' });
    }
    res.json(rows || []);
  });
});

// Get conversion history for a specific user (admin view)
app.get('/api/admin/conversion-history/:userId', (req, res) => {
  const { userId } = req.params;
  const query = `
    SELECT 
      ch.id,
      ch.user_id,
      u.name as user_name,
      u.email as user_email,
      ch.from_currency,
      ch.to_currency,
      ch.amount,
      ch.result,
      ch.timestamp
    FROM conversion_history ch
    JOIN users u ON ch.user_id = u.id
    WHERE ch.user_id = ?
    ORDER BY ch.timestamp DESC
    LIMIT 500
  `;
  
  db.all(query, [userId], (err, rows) => {
    if (err) {
      return res.status(500).json({ error: 'Database error' });
    }
    res.json(rows || []);
  });
});

app.get('/api/admin/expense-split-history/:userId', (req, res) => {
  const { userId } = req.params;
  const query = `
    SELECT
      esh.id,
      esh.user_id,
      u.name as user_name,
      u.email as user_email,
      esh.base_currency,
      esh.total_amount,
      esh.people_count,
      esh.target_currencies,
      esh.per_person_amount,
      esh.timestamp
    FROM expense_split_history esh
    JOIN users u ON esh.user_id = u.id
    WHERE esh.user_id = ?
    ORDER BY esh.timestamp DESC
    LIMIT 500
  `;

  db.all(query, [userId], (err, rows) => {
    if (err) {
      return res.status(500).json({ error: 'Database error' });
    }

    const parsedRows = (rows || []).map((row) => ({
      ...row,
      target_currencies: (() => {
        try {
          return JSON.parse(row.target_currencies);
        } catch {
          return [];
        }
      })(),
    }));

    res.json(parsedRows);
  });
});

function getLanIPv4s() {
  const addrs = [];
  const nets = os.networkInterfaces();
  for (const entries of Object.values(nets)) {
    if (!entries) continue;
    for (const entry of entries) {
      if (!entry.internal && (entry.family === 'IPv4' || entry.family === 4)) {
        addrs.push(entry.address);
      }
    }
  }
  return addrs;
}

const server = app.listen(PORT, HOST, () => {
  console.log(`Server is running on http://${HOST}:${PORT}`);
  const lan = getLanIPv4s();
  if (lan.length) {
    lan.forEach((ip) => console.log(`LAN access: http://${ip}:${PORT}`));
  } else {
    console.log('No LAN IPv4 found; use this machine\'s IP manually for other devices.');
  }
});

// Handle errors
server.on('error', (err) => {
  console.error('Server error:', err);
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception:', err);
});
